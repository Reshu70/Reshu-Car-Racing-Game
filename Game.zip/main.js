var blueCar = document.getElementsById("blueCar");

// blue car move

blueCar.addEventListener("animationiteration",function(){
    var random =((Math.floor(Math.random()*3))*130)
    blueCar.style.left = random +"px"
})